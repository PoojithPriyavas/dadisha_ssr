import React from 'react';

export default function MyAddress() {
  return (
    <div className="container pb-10">
      <h2 className="fw-700 mb-4">My Address</h2>
    </div>
  );
}
