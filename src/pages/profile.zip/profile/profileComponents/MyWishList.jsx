import React from 'react';

export default function MyWishList() {
  return (
    <div className="container pb-10">
      <h2 className="fw-700 mb-4"> Whishlist</h2>
    </div>
  );
}
