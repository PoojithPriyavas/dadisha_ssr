import React from 'react';

export default function MyOrders() {
  return (
    <div className="container pb-10">
      <h2 className="fw-700 mb-4">Account Info</h2>
    </div>
  );
}
