import React from 'react';

export default function MyProfile() {
  return (
    <div className="container pb-10">
      <h2 className="fw-700 mb-4">Account Info</h2>
      <form className="d-flex flex-column  gap-4">
        <div className="d-flex gap-4">
          <div className="form-group w-full">
            <label htmlFor="firstName">
              First Name <span className="text-red">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              id="firstName"
              placeholder="Enter first name"
            />
          </div>
          <div className="form-group w-full">
            <label htmlFor="lastName">
              Last Name <span className="text-red">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              id="lastName"
              placeholder="Enter last name"
            />
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="email">
            Email Address <span className="text-red">*</span>
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            placeholder="Enter email"
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone Number (Optional)</label>
          <input
            type="tel"
            className="form-control"
            id="phone"
            placeholder="Enter phone number"
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 text-white rounded-xl border-none hover-btn"
          style={{ width: 'fit-content', backgroundColor: '#fbae24' }}
        >
          Save
        </button>
      </form>
    </div>
  );
}
